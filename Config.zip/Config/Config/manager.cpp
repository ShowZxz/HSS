#include "manager.h"

Manager::Manager() {}
