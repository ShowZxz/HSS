/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.5.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QComboBox *comboBox_ScreeNumber;
    QLabel *label_2;
    QLabel *label_3;
    QComboBox *comboBox_Resolution;
    QLabel *label;
    QLineEdit *lineEdit_username;
    QLabel *label_4;
    QLineEdit *lineEdit_code;
    QLabel *label_5;
    QPushButton *pushButton_testScreen;
    QPushButton *pushButton_Save;
    QPushButton *pushButton_Inscription;
    QPushButton *pushButton_Close;
    QFrame *line;
    QFrame *line_2;
    QFrame *line_3;
    QFrame *line_4;
    QFrame *line_5;
    QLabel *label_6;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName("MainWindow");
        MainWindow->resize(804, 596);
        MainWindow->setStyleSheet(QString::fromUtf8("\n"
"background-color: rgb(242, 242, 255);"));
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName("centralwidget");
        centralwidget->setStyleSheet(QString::fromUtf8(""));
        comboBox_ScreeNumber = new QComboBox(centralwidget);
        comboBox_ScreeNumber->addItem(QString());
        comboBox_ScreeNumber->addItem(QString());
        comboBox_ScreeNumber->addItem(QString());
        comboBox_ScreeNumber->addItem(QString());
        comboBox_ScreeNumber->addItem(QString());
        comboBox_ScreeNumber->setObjectName("comboBox_ScreeNumber");
        comboBox_ScreeNumber->setGeometry(QRect(240, 190, 211, 31));
        comboBox_ScreeNumber->setStyleSheet(QString::fromUtf8("QComboBox {\n"
"    background-color: #ffffff; /* White background */\n"
"    color: #333333; /* Dark gray text */\n"
"    border: 2px solid #719fee; /* Blue border */\n"
"    border-radius: 5px; /* Rounded corners */\n"
"    padding: 5px 10px; /* Padding inside the combobox */\n"
"    font-size: 16px; /* Font size */\n"
"}\n"
"\n"
"QComboBox:hover {\n"
"    background-color: #e6f0ff; /* Light blue background on hover */\n"
"    border: 2px solid #5b8bcc; /* Darker blue border on hover */\n"
"}\n"
"\n"
"QComboBox::drop-down {\n"
"    subcontrol-origin: padding;\n"
"    subcontrol-position: top right;\n"
"    width: 30px; /* Width of the drop-down button */\n"
"    border-left: 1px solid #719fee; /* Border for the drop-down button */\n"
"}\n"
"\n"
"QComboBox::down-arrow {\n"
"    image: url(:/downArrow.png); /* Custom down arrow icon */\n"
"    width: 10px; /* Width of the arrow */\n"
"    height: 10px; /* Height of the arrow */\n"
"}\n"
"\n"
"QComboBox QAbstractItemView {\n"
"    background-color: #ffffff; /* "
                        "Background of the drop-down list */\n"
"    color: #333333; /* Text color in the drop-down list */\n"
"    border: 1px solid #719fee; /* Border of the drop-down list */\n"
"    selection-background-color: #719fee; /* Background color of selected item */\n"
"    selection-color: #ffffff; /* Text color of selected item */\n"
"}\n"
""));
        label_2 = new QLabel(centralwidget);
        label_2->setObjectName("label_2");
        label_2->setGeometry(QRect(120, 10, 551, 91));
        label_2->setStyleSheet(QString::fromUtf8("background: transparent;\n"
"QLabel.title {\n"
"    color: #719fee; /* Blue text */\n"
"    font-size: 24px; /* Larger font size */\n"
"    font-weight: bold; /* Bold text */\n"
"    padding: 5px 0; /* Padding */\n"
"}\n"
"\n"
""));
        label_3 = new QLabel(centralwidget);
        label_3->setObjectName("label_3");
        label_3->setGeometry(QRect(10, 290, 231, 41));
        label_3->setStyleSheet(QString::fromUtf8("background: transparent;\n"
"\n"
"QLabel {\n"
"    color: #333333; /* Dark gray text */\n"
"    font-size: 14px; /* Font size */\n"
"    padding: 2px; /* Padding */\n"
"}"));
        comboBox_Resolution = new QComboBox(centralwidget);
        comboBox_Resolution->addItem(QString());
        comboBox_Resolution->addItem(QString());
        comboBox_Resolution->addItem(QString());
        comboBox_Resolution->setObjectName("comboBox_Resolution");
        comboBox_Resolution->setGeometry(QRect(240, 300, 211, 31));
        comboBox_Resolution->setStyleSheet(QString::fromUtf8("QComboBox {\n"
"    background-color: #ffffff; /* White background */\n"
"    color: #333333; /* Dark gray text */\n"
"    border: 2px solid #719fee; /* Blue border */\n"
"    border-radius: 5px; /* Rounded corners */\n"
"    padding: 5px 10px; /* Padding inside the combobox */\n"
"    font-size: 16px; /* Font size */\n"
"}\n"
"\n"
"QComboBox:hover {\n"
"    background-color: #e6f0ff; /* Light blue background on hover */\n"
"    border: 2px solid #5b8bcc; /* Darker blue border on hover */\n"
"}\n"
"\n"
"QComboBox::drop-down {\n"
"    subcontrol-origin: padding;\n"
"    subcontrol-position: top right;\n"
"    width: 30px; /* Width of the drop-down button */\n"
"    border-left: 1px solid #719fee; /* Border for the drop-down button */\n"
"}\n"
"\n"
"QComboBox::down-arrow {\n"
"    image: url(:/downArrow.png); /* Custom down arrow icon */\n"
"    width: 10px; /* Width of the arrow */\n"
"    height: 10px; /* Height of the arrow */\n"
"}\n"
"\n"
"QComboBox QAbstractItemView {\n"
"    background-color: #ffffff; /* "
                        "Background of the drop-down list */\n"
"    color: #333333; /* Text color in the drop-down list */\n"
"    border: 1px solid #719fee; /* Border of the drop-down list */\n"
"    selection-background-color: #719fee; /* Background color of selected item */\n"
"    selection-color: #ffffff; /* Text color of selected item */\n"
"}\n"
""));
        label = new QLabel(centralwidget);
        label->setObjectName("label");
        label->setGeometry(QRect(10, 170, 221, 71));
        label->setStyleSheet(QString::fromUtf8("background: transparent;\n"
"\n"
"QLabel {\n"
"    color: #333333; /* Dark gray text */\n"
"    font-size: 14px; /* Font size */\n"
"    padding: 2px; /* Padding */\n"
"}"));
        lineEdit_username = new QLineEdit(centralwidget);
        lineEdit_username->setObjectName("lineEdit_username");
        lineEdit_username->setGeometry(QRect(150, 450, 201, 41));
        lineEdit_username->setStyleSheet(QString::fromUtf8("QLineEdit {\n"
"    background-color: #ffffff; /* White background */\n"
"    color: #333333; /* Dark gray text */\n"
"    border: 2px solid #719fee; /* Blue border */\n"
"    border-radius: 5px; /* Rounded corners */\n"
"    padding: 5px; /* Padding inside the line edit */\n"
"    font-size: 16px; /* Font size */\n"
"}\n"
"\n"
"QLineEdit:hover {\n"
"    background-color: #f0f8ff; /* Light blue background on hover */\n"
"    border: 2px solid #5b8bcc; /* Darker blue border on hover */\n"
"}\n"
"\n"
"QLineEdit:focus {\n"
"    background-color: #ffffff; /* White background when focused */\n"
"    border: 2px solid #3a6fab; /* Even darker blue border when focused */\n"
"    outline: none; /* Remove the default focus outline */\n"
"}\n"
""));
        label_4 = new QLabel(centralwidget);
        label_4->setObjectName("label_4");
        label_4->setGeometry(QRect(180, 390, 121, 51));
        label_4->setStyleSheet(QString::fromUtf8("background: transparent;\n"
"\n"
"QLabel {\n"
"    color: #333333; /* Dark gray text */\n"
"    font-size: 14px; /* Font size */\n"
"    padding: 2px; /* Padding */\n"
"}"));
        lineEdit_code = new QLineEdit(centralwidget);
        lineEdit_code->setObjectName("lineEdit_code");
        lineEdit_code->setGeometry(QRect(420, 450, 191, 41));
        lineEdit_code->setStyleSheet(QString::fromUtf8("QLineEdit {\n"
"    background-color: #ffffff; /* White background */\n"
"    color: #333333; /* Dark gray text */\n"
"    border: 2px solid #719fee; /* Blue border */\n"
"    border-radius: 5px; /* Rounded corners */\n"
"    padding: 5px; /* Padding inside the line edit */\n"
"    font-size: 16px; /* Font size */\n"
"}\n"
"\n"
"QLineEdit:hover {\n"
"    background-color: #f0f8ff; /* Light blue background on hover */\n"
"    border: 2px solid #5b8bcc; /* Darker blue border on hover */\n"
"}\n"
"\n"
"QLineEdit:focus {\n"
"    background-color: #ffffff; /* White background when focused */\n"
"    border: 2px solid #3a6fab; /* Even darker blue border when focused */\n"
"    outline: none; /* Remove the default focus outline */\n"
"}\n"
""));
        label_5 = new QLabel(centralwidget);
        label_5->setObjectName("label_5");
        label_5->setGeometry(QRect(450, 390, 131, 51));
        label_5->setStyleSheet(QString::fromUtf8("background: transparent;\n"
"QLabel {\n"
"    color: #333333; /* Dark gray text */\n"
"    font-size: 14px; /* Font size */\n"
"    padding: 2px; /* Padding */\n"
"}"));
        pushButton_testScreen = new QPushButton(centralwidget);
        pushButton_testScreen->setObjectName("pushButton_testScreen");
        pushButton_testScreen->setGeometry(QRect(520, 190, 121, 41));
        pushButton_testScreen->setStyleSheet(QString::fromUtf8(" QPushButton {\n"
"            background-color: #A9A9A9;\n"
"            color: white;\n"
"            border: 2px solid #000000;\n"
"            border-radius: 10px;\n"
"            padding: 5px 15px;\n"
"            font-size: 16px;\n"
"            font-weight: bold;\n"
"            text-align: center;\n"
"        }\n"
"        QPushButton:hover {\n"
"            background-color: #5b8bcc;\n"
"            border: 2px solid #3a6fab;\n"
"        }\n"
"        QPushButton:pressed {\n"
"            background-color: #3a6fab;\n"
"            border: 2px solid #1f4f8b;\n"
"        }"));
        pushButton_Save = new QPushButton(centralwidget);
        pushButton_Save->setObjectName("pushButton_Save");
        pushButton_Save->setGeometry(QRect(50, 540, 141, 31));
        pushButton_Save->setStyleSheet(QString::fromUtf8(" QPushButton {\n"
"            background-color: #A9A9A9;\n"
"            color: white;\n"
"            border: 2px solid #000000;\n"
"            border-radius: 10px;\n"
"            padding: 5px 15px;\n"
"            font-size: 16px;\n"
"            font-weight: bold;\n"
"            text-align: center;\n"
"        }\n"
"        QPushButton:hover {\n"
"            background-color: #5b8bcc;\n"
"            border: 2px solid #3a6fab;\n"
"        }\n"
"        QPushButton:pressed {\n"
"            background-color: #3a6fab;\n"
"            border: 2px solid #1f4f8b;\n"
"        }"));
        pushButton_Inscription = new QPushButton(centralwidget);
        pushButton_Inscription->setObjectName("pushButton_Inscription");
        pushButton_Inscription->setGeometry(QRect(310, 540, 151, 31));
        pushButton_Inscription->setStyleSheet(QString::fromUtf8(" QPushButton {\n"
"            background-color: #A9A9A9;\n"
"            color: white;\n"
"            border: 2px solid #000000;\n"
"            border-radius: 10px;\n"
"            padding: 5px 15px;\n"
"            font-size: 16px;\n"
"            font-weight: bold;\n"
"            text-align: center;\n"
"        }\n"
"        QPushButton:hover {\n"
"            background-color: #5b8bcc;\n"
"            border: 2px solid #3a6fab;\n"
"        }\n"
"        QPushButton:pressed {\n"
"            background-color: #3a6fab;\n"
"            border: 2px solid #1f4f8b;\n"
"        }"));
        pushButton_Close = new QPushButton(centralwidget);
        pushButton_Close->setObjectName("pushButton_Close");
        pushButton_Close->setGeometry(QRect(540, 540, 161, 31));
        pushButton_Close->setStyleSheet(QString::fromUtf8(" QPushButton {\n"
"            background-color: #A9A9A9;\n"
"            color: white;\n"
"            border: 2px solid #000000;\n"
"            border-radius: 10px;\n"
"            padding: 5px 15px;\n"
"            font-size: 16px;\n"
"            font-weight: bold;\n"
"            text-align: center;\n"
"        }\n"
"        QPushButton:hover {\n"
"            background-color: #5b8bcc;\n"
"            border: 2px solid #3a6fab;\n"
"        }\n"
"        QPushButton:pressed {\n"
"            background-color: #3a6fab;\n"
"            border: 2px solid #1f4f8b;\n"
"        }"));
        line = new QFrame(centralwidget);
        line->setObjectName("line");
        line->setGeometry(QRect(0, 330, 821, 16));
        line->setFrameShape(QFrame::HLine);
        line->setFrameShadow(QFrame::Sunken);
        line_2 = new QFrame(centralwidget);
        line_2->setObjectName("line_2");
        line_2->setGeometry(QRect(0, 280, 811, 20));
        line_2->setFrameShape(QFrame::HLine);
        line_2->setFrameShadow(QFrame::Sunken);
        line_3 = new QFrame(centralwidget);
        line_3->setObjectName("line_3");
        line_3->setGeometry(QRect(0, 240, 811, 20));
        line_3->setFrameShape(QFrame::HLine);
        line_3->setFrameShadow(QFrame::Sunken);
        line_4 = new QFrame(centralwidget);
        line_4->setObjectName("line_4");
        line_4->setGeometry(QRect(-3, 160, 811, 20));
        line_4->setFrameShape(QFrame::HLine);
        line_4->setFrameShadow(QFrame::Sunken);
        line_5 = new QFrame(centralwidget);
        line_5->setObjectName("line_5");
        line_5->setGeometry(QRect(0, 510, 811, 20));
        line_5->setFrameShape(QFrame::HLine);
        line_5->setFrameShadow(QFrame::Sunken);
        label_6 = new QLabel(centralwidget);
        label_6->setObjectName("label_6");
        label_6->setGeometry(QRect(670, 180, 101, 61));
        label_6->setStyleSheet(QString::fromUtf8("background: transparent;\n"
"QLabel {\n"
"    color: #333333; /* Dark gray text */\n"
"    font-size: 14px; /* Font size */\n"
"    padding: 2px; /* Padding */\n"
"}"));
        MainWindow->setCentralWidget(centralwidget);

        retranslateUi(MainWindow);
        QObject::connect(pushButton_Close, &QPushButton::clicked, MainWindow, qOverload<>(&QMainWindow::close));

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "Config", nullptr));
        comboBox_ScreeNumber->setItemText(0, QCoreApplication::translate("MainWindow", "1", nullptr));
        comboBox_ScreeNumber->setItemText(1, QCoreApplication::translate("MainWindow", "2", nullptr));
        comboBox_ScreeNumber->setItemText(2, QCoreApplication::translate("MainWindow", "3", nullptr));
        comboBox_ScreeNumber->setItemText(3, QCoreApplication::translate("MainWindow", "4", nullptr));
        comboBox_ScreeNumber->setItemText(4, QCoreApplication::translate("MainWindow", "5", nullptr));

        label_2->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p align=\"center\"><span style=\" font-size:26pt;\">HIGHSCORE SYSTEM CONFIG</span></p></body></html>", nullptr));
        label_3->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:10pt; font-weight:700;\">Type of resolution</span></p></body></html>", nullptr));
        comboBox_Resolution->setItemText(0, QString());
        comboBox_Resolution->setItemText(1, QCoreApplication::translate("MainWindow", "1280 x 720", nullptr));
        comboBox_Resolution->setItemText(2, QCoreApplication::translate("MainWindow", "1920 x 1080", nullptr));

        label->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p align=\"justify\"><span style=\" font-size:10pt; font-weight:700;\">Select the screen were</span></p><p align=\"justify\"><span style=\" font-size:10pt; font-weight:700;\">you want to display the application</span></p></body></html>", nullptr));
        label_4->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p align=\"center\"><span style=\" font-size:10pt; font-weight:700;\">Username</span></p><p align=\"center\"><span style=\" font-size:10pt; font-weight:700;\">|</span></p><p align=\"center\"><span style=\" font-size:10pt; font-weight:700;\"><br/></span></p><p><span style=\" font-size:10pt; font-weight:700;\"><br/></span></p></body></html>", nullptr));
        label_5->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p align=\"center\"><span style=\" font-size:10pt; font-weight:700;\">Code</span></p><p align=\"center\"><span style=\" font-size:10pt; font-weight:700;\">|</span></p></body></html>", nullptr));
        pushButton_testScreen->setText(QCoreApplication::translate("MainWindow", "Test Screen", nullptr));
        pushButton_Save->setText(QCoreApplication::translate("MainWindow", "Save", nullptr));
        pushButton_Inscription->setText(QCoreApplication::translate("MainWindow", "Inscription", nullptr));
        pushButton_Close->setText(QCoreApplication::translate("MainWindow", "Close", nullptr));
        label_6->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p align=\"center\"><span style=\" font-size:10pt; font-weight:700;\">Test your screen<br/>before saving</span></p></body></html>", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
